// © 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html

u"saħħa";
u'文';
u"𡧲";
u"Μυστήριο";

 u"saħħa";
 u'文'; u"𡧲";

u8" \u0301";
u8"\u0308 ";
u8"saħħa";
u8"文";
u8"𡧲";
u8"saħ\u0127a";
